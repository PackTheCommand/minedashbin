from .independentComponents import *
from .staticPy import Collor
from .fileEditor import  *